This is a simple scheduler program for automatically creating and editing tasks on defined days on an excel
sheet when given prescribed dates. Hope you enjoy!

How to Use:

-Put the excel files you wish to edit in the same folder as this programs .exe file
-When entering numbers all entries must be single digit
-Do not separate the .exe file from the images

Use Existing:
This is for adding to an existing file. Simply, enter the file name(no extension) and enter the rest of your 
information accordingly.

Add WorkBook:

This is for creating a new excel file. Simply, enter what you would like to call the 
file(no extension,no special characters) and enter the rest of your information accordingly.
You must initilize it with a Qual entry